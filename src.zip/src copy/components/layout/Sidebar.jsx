import { NavLink, useNavigate } from 'react-router-dom'
import { supabase } from '../../supabaseClient'

const NAV = [
  { to: '/',              icon: '⬛', label: 'Dashboard' },
  { to: '/tournaments',   icon: '🏆', label: 'Tournaments' },
  { to: '/teams',         icon: '🏀', label: 'Teams' },
  { to: '/registrations', icon: '📋', label: 'Registrations' },
]

export default function Sidebar({ director }) {
  const navigate = useNavigate()

  async function handleSignOut() {
    await supabase.auth.signOut()
    navigate('/login')
  }

  return (
    <div style={{
      width: 220, background: '#080c12', borderRight: '1px solid #1a2030',
      display: 'flex', flexDirection: 'column', flexShrink: 0, minHeight: '100vh'
    }}>
      {/* Logo */}
      <div style={{ padding: '20px 18px 16px', borderBottom: '1px solid #1a2030' }}>
        <div style={{ fontFamily: 'Anton, sans-serif', fontSize: 16, color: '#5cb800', letterSpacing: 1 }}>NP TOURNAMENTS</div>
        <div style={{ fontSize: 10, color: '#2a3548', textTransform: 'uppercase', letterSpacing: '1.5px', marginTop: 2 }}>Director Portal</div>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: '12px 10px' }}>
        {NAV.map(({ to, icon, label }) => (
          <NavLink key={to} to={to} end={to === '/'}
            style={({ isActive }) => ({
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '9px 10px', borderRadius: 8, marginBottom: 2,
              fontSize: 13, fontWeight: 500, textDecoration: 'none',
              background: isActive ? '#0d1a0a' : 'transparent',
              color: isActive ? '#5cb800' : '#6b7a99',
              border: isActive ? '1px solid #1a3a0a' : '1px solid transparent',
              transition: 'all 0.12s'
            })}
          >
            <span style={{ fontSize: 15 }}>{icon}</span>
            {label}
          </NavLink>
        ))}
      </nav>

      {/* User */}
      <div style={{ padding: '14px 18px', borderTop: '1px solid #1a2030' }}>
        {director && (
          <div style={{ marginBottom: 10 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: '#c0cce0' }}>{director.display_name}</div>
            <div style={{ fontSize: 11, color: '#4a5568', marginTop: 1 }}>{director.email}</div>
          </div>
        )}
        <button onClick={handleSignOut}
          style={{ width: '100%', background: 'transparent', border: '1px solid #1a2030', color: '#4a5568', padding: '7px', borderRadius: 8, fontSize: 12 }}>
          Sign Out
        </button>
      </div>
    </div>
  )
}
