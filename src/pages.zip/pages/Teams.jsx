import { useState, useRef } from 'react'
import Topbar from '../components/layout/Topbar'
import { useTeams } from '../hooks/useTeams'

const GENDERS = ['Male', 'Female', 'Coed']
const AGE_GROUPS = ['8U','10U','11U','12U','13U','14U','15U','16U','17U','18U','Adult']
const SKILL_LEVELS = ['Recreational', 'Competitive', 'Elite', 'Pro']
const PAYMENT_METHODS = ['Check', 'Cash', 'Venmo', 'Zelle', 'Credit Card', 'Invoice']

// ── Org Dedup Search ──────────────────────────────────────────────
function OrgSearch({ value, onChange, searchOrgs }) {
  const [suggestions, setSuggestions] = useState([])
  const [open, setOpen] = useState(false)

  async function handleInput(e) {
    const v = e.target.value
    onChange(v)
    if (v.length >= 2) {
      const results = await searchOrgs(v)
      setSuggestions(results)
      setOpen(results.length > 0)
    } else {
      setOpen(false)
    }
  }

  return (
    <div style={{ position: 'relative' }}>
      <input
        type="text"
        value={value}
        onChange={handleInput}
        placeholder="e.g. Delta Dubs"
        style={{ width: '100%' }}
      />
      {open && (
        <div style={{
          position: 'absolute', top: '100%', left: 0, right: 0, zIndex: 100,
          background: '#0e1320', border: '1px solid #1a2030', borderRadius: 8,
          marginTop: 4, overflow: 'hidden'
        }}>
          <div style={{ padding: '6px 12px', fontSize: 11, color: '#4a5568', borderBottom: '1px solid #1a2030' }}>
            Existing orgs — select to link or keep typing for new
          </div>
          {suggestions.map(s => (
            <div key={s} onClick={() => { onChange(s); setOpen(false) }}
              style={{ padding: '9px 12px', fontSize: 13, color: '#c0cce0', cursor: 'pointer', borderBottom: '1px solid #0e1320' }}
              onMouseEnter={e => e.currentTarget.style.background = '#1a2030'}
              onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
            >
              {s}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ── Team Form Modal ───────────────────────────────────────────────
function TeamModal({ onClose, onSave, searchOrgs, initial }) {
  const [form, setForm] = useState(initial || {
    name: '', org_name: '', gender: '', age_group: '', skill_level: '',
    coach_name: '', coach_email: '', coach_phone: '',
    asst_coach_name: '', asst_coach_email: '', asst_coach_phone: '',
    location: '', jersey_colors: '', payment_method: '', notes: ''
  })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  function set(key, val) { setForm(f => ({ ...f, [key]: val })) }

  async function handleSave() {
    if (!form.name) { setError('Team name is required'); return }
    if (!form.org_name) { setError('Org name is required'); return }
    setSaving(true)
    const { error } = await onSave(form)
    if (error) { setError(error.message); setSaving(false) }
    else onClose()
  }

  const labelStyle = { fontSize: 11, color: '#4a5568', textTransform: 'uppercase', letterSpacing: 1, display: 'block', marginBottom: 6 }
  const sectionStyle = { marginBottom: 24 }
  const sectionHeader = { fontSize: 11, color: '#5cb800', textTransform: 'uppercase', letterSpacing: '1.5px', marginBottom: 14, paddingBottom: 6, borderBottom: '1px solid #1a2030' }
  const grid2 = { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
      <div style={{ background: '#080c12', border: '1px solid #1a2030', borderRadius: 16, width: '100%', maxWidth: 600, maxHeight: '90vh', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        
        {/* Header */}
        <div style={{ padding: '18px 24px', borderBottom: '1px solid #1a2030', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'Anton, sans-serif', fontSize: 18, color: '#5cb800', letterSpacing: 1 }}>{initial ? 'EDIT TEAM' : 'ADD TEAM'}</span>
          <button onClick={onClose} style={{ background: 'transparent', border: 'none', color: '#4a5568', fontSize: 20, lineHeight: 1 }}>×</button>
        </div>

        {/* Body */}
        <div style={{ padding: 24, overflowY: 'auto', flex: 1 }}>

          {/* Team Info */}
          <div style={sectionStyle}>
            <div style={sectionHeader}>Team Info</div>
            <div style={{ ...grid2, marginBottom: 14 }}>
              <div>
                <label style={labelStyle}>Team Name *</label>
                <input type="text" value={form.name} onChange={e => set('name', e.target.value)} placeholder="e.g. Delta Dubs 16U" style={{ width: '100%' }} />
              </div>
              <div>
                <label style={labelStyle}>Organization *</label>
                <OrgSearch value={form.org_name} onChange={v => set('org_name', v)} searchOrgs={searchOrgs} />
              </div>
            </div>
            <div style={grid2}>
              <div>
                <label style={labelStyle}>Gender</label>
                <select value={form.gender} onChange={e => set('gender', e.target.value)} style={{ width: '100%' }}>
                  <option value="">Select</option>
                  {GENDERS.map(g => <option key={g} value={g}>{g}</option>)}
                </select>
              </div>
              <div>
                <label style={labelStyle}>Age Group</label>
                <select value={form.age_group} onChange={e => set('age_group', e.target.value)} style={{ width: '100%' }}>
                  <option value="">Select</option>
                  {AGE_GROUPS.map(a => <option key={a} value={a}>{a}</option>)}
                </select>
              </div>
            </div>
            <div style={{ ...grid2, marginTop: 14 }}>
              <div>
                <label style={labelStyle}>Skill Level</label>
                <select value={form.skill_level} onChange={e => set('skill_level', e.target.value)} style={{ width: '100%' }}>
                  <option value="">Select</option>
                  {SKILL_LEVELS.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div>
                <label style={labelStyle}>Location</label>
                <input type="text" value={form.location} onChange={e => set('location', e.target.value)} placeholder="e.g. Oakland, CA" style={{ width: '100%' }} />
              </div>
            </div>
            <div style={{ marginTop: 14 }}>
              <label style={labelStyle}>Jersey Colors</label>
              <input type="text" value={form.jersey_colors} onChange={e => set('jersey_colors', e.target.value)} placeholder="e.g. Black/Green" style={{ width: '100%' }} />
            </div>
          </div>

          {/* Head Coach */}
          <div style={sectionStyle}>
            <div style={sectionHeader}>Head Coach</div>
            <div style={{ marginBottom: 14 }}>
              <label style={labelStyle}>Full Name</label>
              <input type="text" value={form.coach_name} onChange={e => set('coach_name', e.target.value)} placeholder="Coach name" style={{ width: '100%' }} />
            </div>
            <div style={grid2}>
              <div>
                <label style={labelStyle}>Email</label>
                <input type="email" value={form.coach_email} onChange={e => set('coach_email', e.target.value)} placeholder="coach@email.com" style={{ width: '100%' }} />
              </div>
              <div>
                <label style={labelStyle}>Phone</label>
                <input type="tel" value={form.coach_phone} onChange={e => set('coach_phone', e.target.value)} placeholder="(555) 000-0000" style={{ width: '100%' }} />
              </div>
            </div>
          </div>

          {/* Assistant Coach */}
          <div style={sectionStyle}>
            <div style={sectionHeader}>Assistant Coach</div>
            <div style={{ marginBottom: 14 }}>
              <label style={labelStyle}>Full Name</label>
              <input type="text" value={form.asst_coach_name} onChange={e => set('asst_coach_name', e.target.value)} placeholder="Assistant coach name" style={{ width: '100%' }} />
            </div>
            <div style={grid2}>
              <div>
                <label style={labelStyle}>Email</label>
                <input type="email" value={form.asst_coach_email} onChange={e => set('asst_coach_email', e.target.value)} placeholder="asst@email.com" style={{ width: '100%' }} />
              </div>
              <div>
                <label style={labelStyle}>Phone</label>
                <input type="tel" value={form.asst_coach_phone} onChange={e => set('asst_coach_phone', e.target.value)} placeholder="(555) 000-0000" style={{ width: '100%' }} />
              </div>
            </div>
          </div>

          {/* Payment */}
          <div style={sectionStyle}>
            <div style={sectionHeader}>Payment</div>
            <div>
              <label style={labelStyle}>Preferred Payment Method</label>
              <select value={form.payment_method} onChange={e => set('payment_method', e.target.value)} style={{ width: '100%' }}>
                <option value="">Select</option>
                {PAYMENT_METHODS.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
          </div>

          {/* Notes */}
          <div style={sectionStyle}>
            <div style={sectionHeader}>Notes</div>
            <textarea value={form.notes} onChange={e => set('notes', e.target.value)} placeholder="Any additional notes..." rows={3}
              style={{ width: '100%', resize: 'vertical', fontFamily: 'DM Sans, sans-serif', fontSize: 13, background: '#0e1320', border: '1px solid #1a2030', color: '#f0f4ff', borderRadius: 8, padding: '8px 12px' }} />
          </div>

          {error && <div style={{ fontSize: 12, color: '#e05555', background: '#1f0707', border: '1px solid #3a0a0a', padding: '8px 12px', borderRadius: 6, marginBottom: 12 }}>{error}</div>}
        </div>

        {/* Footer */}
        <div style={{ padding: '16px 24px', borderTop: '1px solid #1a2030', display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
          <button onClick={onClose} style={{ background: 'transparent', color: '#6b7a99', border: '1px solid #1a2030', padding: '9px 18px', borderRadius: 8, fontSize: 13 }}>Cancel</button>
          <button onClick={handleSave} disabled={saving}
            style={{ background: '#5cb800', color: '#04060a', border: 'none', padding: '9px 20px', borderRadius: 8, fontSize: 13, fontWeight: 700, opacity: saving ? 0.6 : 1 }}>
            {saving ? 'Saving...' : initial ? 'Save Changes' : 'Add Team'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ── CSV Import Modal ──────────────────────────────────────────────
function CSVModal({ onClose, onImport }) {
  const fileRef = useRef()
  const [rows, setRows] = useState([])
  const [error, setError] = useState('')
  const [importing, setImporting] = useState(false)
  const [imported, setImported] = useState(false)

  const HEADERS = ['name','org_name','gender','age_group','skill_level','coach_name','coach_email','coach_phone','asst_coach_name','asst_coach_email','location','jersey_colors','payment_method']

  function parseCSV(text) {
    const lines = text.trim().split('\n')
    const headers = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/ /g,'_'))
    return lines.slice(1).map(line => {
      const vals = line.split(',').map(v => v.trim().replace(/^"|"$/g,''))
      const obj = {}
      headers.forEach((h, i) => { obj[h] = vals[i] || '' })
      return obj
    }).filter(r => r.name)
  }

  function handleFile(e) {
    const file = e.target.files[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = ev => {
      try {
        const parsed = parseCSV(ev.target.result)
        setRows(parsed)
        setError('')
      } catch {
        setError('Could not parse CSV. Check the format.')
      }
    }
    reader.readAsText(file)
  }

  async function handleImport() {
    setImporting(true)
    const { error } = await onImport(rows)
    if (error) { setError(error.message); setImporting(false) }
    else { setImported(true); setImporting(false) }
  }

  function downloadTemplate() {
    const csv = HEADERS.join(',') + '\nDelta Dubs 16U,Delta Dubs,Male,16U,Elite,Jay Smith,jay@email.com,5550001234,,,Oakland CA,Black/Green,Zelle'
    const blob = new Blob([csv], { type: 'text/csv' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'teams_template.csv'
    a.click()
  }

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
      <div style={{ background: '#080c12', border: '1px solid #1a2030', borderRadius: 16, width: '100%', maxWidth: 560 }}>
        <div style={{ padding: '18px 24px', borderBottom: '1px solid #1a2030', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'Anton, sans-serif', fontSize: 18, color: '#5cb800', letterSpacing: 1 }}>CSV IMPORT</span>
          <button onClick={onClose} style={{ background: 'transparent', border: 'none', color: '#4a5568', fontSize: 20 }}>×</button>
        </div>

        <div style={{ padding: 24 }}>
          {imported ? (
            <div style={{ textAlign: 'center', padding: '24px 0' }}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>✅</div>
              <div style={{ fontSize: 15, color: '#5cb800', fontWeight: 600 }}>{rows.length} teams imported successfully!</div>
              <button onClick={onClose} style={{ marginTop: 20, background: '#5cb800', color: '#04060a', border: 'none', padding: '9px 20px', borderRadius: 8, fontSize: 13, fontWeight: 700 }}>Done</button>
            </div>
          ) : (
            <>
              <button onClick={downloadTemplate}
                style={{ width: '100%', background: 'transparent', border: '1px dashed #1a2030', color: '#5cb800', padding: '10px', borderRadius: 8, fontSize: 13, marginBottom: 16 }}>
                ⬇ Download CSV Template
              </button>

              <div onClick={() => fileRef.current.click()}
                style={{ border: '2px dashed #1a2030', borderRadius: 12, padding: '32px', textAlign: 'center', cursor: 'pointer', marginBottom: 16 }}
                onMouseEnter={e => e.currentTarget.style.borderColor = '#5cb800'}
                onMouseLeave={e => e.currentTarget.style.borderColor = '#1a2030'}
              >
                <div style={{ fontSize: 28, marginBottom: 8 }}>📂</div>
                <div style={{ fontSize: 13, color: '#c0cce0' }}>Click to upload CSV</div>
                <div style={{ fontSize: 11, color: '#4a5568', marginTop: 4 }}>or drag and drop</div>
                <input ref={fileRef} type="file" accept=".csv" onChange={handleFile} style={{ display: 'none' }} />
              </div>

              {rows.length > 0 && (
                <div style={{ background: '#0e1320', border: '1px solid #1a2030', borderRadius: 8, padding: '10px 14px', marginBottom: 16 }}>
                  <div style={{ fontSize: 12, color: '#5cb800' }}>✓ {rows.length} teams ready to import</div>
                  <div style={{ fontSize: 11, color: '#4a5568', marginTop: 4 }}>
                    {rows.slice(0, 3).map(r => r.name).join(', ')}{rows.length > 3 ? ` +${rows.length - 3} more` : ''}
                  </div>
                </div>
              )}

              {error && <div style={{ fontSize: 12, color: '#e05555', background: '#1f0707', border: '1px solid #3a0a0a', padding: '8px 12px', borderRadius: 6, marginBottom: 12 }}>{error}</div>}

              <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
                <button onClick={onClose} style={{ background: 'transparent', color: '#6b7a99', border: '1px solid #1a2030', padding: '9px 18px', borderRadius: 8, fontSize: 13 }}>Cancel</button>
                <button onClick={handleImport} disabled={rows.length === 0 || importing}
                  style={{ background: '#5cb800', color: '#04060a', border: 'none', padding: '9px 20px', borderRadius: 8, fontSize: 13, fontWeight: 700, opacity: rows.length === 0 ? 0.4 : 1 }}>
                  {importing ? 'Importing...' : `Import ${rows.length} Teams`}
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

// ── Main Teams Page ───────────────────────────────────────────────
export default function Teams({ director }) {
  const { teams, orgs, loading, createTeam, updateTeam, deleteTeam, searchOrgs, bulkCreateTeams } = useTeams()
  const [showAdd, setShowAdd] = useState(false)
  const [showCSV, setShowCSV] = useState(false)
  const [editTeam, setEditTeam] = useState(null)
  const [search, setSearch] = useState('')
  const [filterGender, setFilterGender] = useState('')
  const [filterAge, setFilterAge] = useState('')
  const [filterSkill, setFilterSkill] = useState('')
  const [expandedOrgs, setExpandedOrgs] = useState({})

  function toggleOrg(org) {
    setExpandedOrgs(p => ({ ...p, [org]: !p[org] }))
  }

  const filtered = teams.filter(t => {
    const q = search.toLowerCase()
    const matchSearch = !q || t.name?.toLowerCase().includes(q) || t.org_name?.toLowerCase().includes(q) || t.coach_name?.toLowerCase().includes(q)
    const matchGender = !filterGender || t.gender === filterGender
    const matchAge = !filterAge || t.age_group === filterAge
    const matchSkill = !filterSkill || t.skill_level === filterSkill
    return matchSearch && matchGender && matchAge && matchSkill
  })

  // Group by org → gender → age → skill
  const grouped = {}
  filtered.forEach(t => {
    const org = t.org_name || 'Unassigned'
    const gender = t.gender || 'Unknown'
    const age = t.age_group || 'Unknown'
    const skill = t.skill_level || 'Unknown'
    if (!grouped[org]) grouped[org] = {}
    if (!grouped[org][gender]) grouped[org][gender] = {}
    if (!grouped[org][gender][age]) grouped[org][gender][age] = {}
    if (!grouped[org][gender][age][skill]) grouped[org][gender][age][skill] = []
    grouped[org][gender][age][skill].push(t)
  })

  const genderColors = { Male: '#3b82f6', Female: '#ec4899', Coed: '#8b5cf6', Unknown: '#4a5568' }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, overflow: 'hidden' }}>
      <Topbar
        title="TEAMS"
        actions={
          <>
            <button onClick={() => setShowCSV(true)} style={{ background: 'transparent', color: '#6b7a99', border: '1px solid #1a2030', padding: '8px 14px', borderRadius: 8, fontSize: 13 }}>
              ⬆ Import CSV
            </button>
            <button onClick={() => setShowAdd(true)} style={{ background: '#5cb800', color: '#04060a', border: 'none', padding: '8px 16px', borderRadius: 8, fontSize: 13, fontWeight: 700 }}>
              + Add Team
            </button>
          </>
        }
      />

      <div style={{ padding: 24, overflowY: 'auto', flex: 1 }}>

        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 14, marginBottom: 24 }}>
          {[
            { label: 'Total Teams', value: teams.length },
            { label: 'Organizations', value: Object.keys(orgs).length },
            { label: 'Age Groups', value: [...new Set(teams.map(t => t.age_group).filter(Boolean))].length },
            { label: 'Active Coaches', value: [...new Set(teams.map(t => t.coach_email).filter(Boolean))].length },
          ].map(s => (
            <div key={s.label} style={{ background: '#080c12', border: '1px solid #1a2030', borderRadius: 12, padding: 16 }}>
              <div style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: '1.2px', color: '#4a5568', marginBottom: 8 }}>{s.label}</div>
              <div style={{ fontFamily: 'Anton, sans-serif', fontSize: 32, color: '#f0f4ff', lineHeight: 1 }}>{s.value}</div>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div style={{ display: 'flex', gap: 10, marginBottom: 20, flexWrap: 'wrap' }}>
          <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search teams, orgs, coaches..."
            style={{ flex: 1, minWidth: 200 }} />
          <select value={filterGender} onChange={e => setFilterGender(e.target.value)} style={{ width: 130 }}>
            <option value="">All Genders</option>
            {GENDERS.map(g => <option key={g} value={g}>{g}</option>)}
          </select>
          <select value={filterAge} onChange={e => setFilterAge(e.target.value)} style={{ width: 120 }}>
            <option value="">All Ages</option>
            {AGE_GROUPS.map(a => <option key={a} value={a}>{a}</option>)}
          </select>
          <select value={filterSkill} onChange={e => setFilterSkill(e.target.value)} style={{ width: 140 }}>
            <option value="">All Skill Levels</option>
            {SKILL_LEVELS.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>

        {/* Team Directory */}
        {loading ? (
          <div style={{ padding: 40, textAlign: 'center', color: '#4a5568', fontSize: 13 }}>Loading teams...</div>
        ) : Object.keys(grouped).length === 0 ? (
          <div style={{ padding: 60, textAlign: 'center' }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>🏀</div>
            <div style={{ fontSize: 14, color: '#4a5568', marginBottom: 16 }}>No teams yet</div>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'center' }}>
              <button onClick={() => setShowCSV(true)} style={{ background: 'transparent', color: '#5cb800', border: '1px solid #5cb800', padding: '9px 20px', borderRadius: 8, fontSize: 13 }}>Import CSV</button>
              <button onClick={() => setShowAdd(true)} style={{ background: '#5cb800', color: '#04060a', border: 'none', padding: '9px 20px', borderRadius: 8, fontSize: 13, fontWeight: 700 }}>Add First Team</button>
            </div>
          </div>
        ) : Object.entries(grouped).map(([org, genders]) => (
          <div key={org} style={{ marginBottom: 12, background: '#080c12', border: '1px solid #1a2030', borderRadius: 12, overflow: 'hidden' }}>
            {/* Org Header */}
            <div onClick={() => toggleOrg(org)}
              style={{ padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer', borderBottom: expandedOrgs[org] === false ? 'none' : '1px solid #1a2030' }}
              onMouseEnter={e => e.currentTarget.style.background = '#0a0f1a'}
              onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
            >
              <div style={{ width: 36, height: 36, borderRadius: 8, background: '#0d1a0a', border: '1px solid #1a3a0a', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>🏢</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: 'Anton, sans-serif', fontSize: 15, color: '#f0f4ff', letterSpacing: 0.5 }}>{org}</div>
                <div style={{ fontSize: 11, color: '#4a5568', marginTop: 2 }}>
                  {Object.values(genders).flatMap(g => Object.values(g).flatMap(a => Object.values(a))).flat().length} teams
                </div>
              </div>
              <span style={{ color: '#4a5568', fontSize: 18 }}>{expandedOrgs[org] === false ? '▶' : '▼'}</span>
            </div>

            {expandedOrgs[org] !== false && Object.entries(genders).map(([gender, ages]) => (
              <div key={gender} style={{ paddingLeft: 18 }}>
                {/* Gender Row */}
                <div style={{ padding: '10px 18px 10px 0', borderBottom: '1px solid #0e1320', display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ width: 8, height: 8, borderRadius: '50%', background: genderColors[gender] || '#4a5568' }} />
                  <span style={{ fontSize: 11, fontWeight: 600, color: '#8898b8', textTransform: 'uppercase', letterSpacing: 1 }}>{gender}</span>
                </div>

                {Object.entries(ages).map(([age, skills]) => (
                  <div key={age} style={{ paddingLeft: 16 }}>
                    {/* Age Row */}
                    <div style={{ padding: '8px 18px 8px 0', borderBottom: '1px solid #0e1320', fontSize: 11, color: '#4a5568', textTransform: 'uppercase', letterSpacing: 1 }}>
                      {age}
                    </div>

                    {Object.entries(skills).map(([skill, skillTeams]) => (
                      <div key={skill} style={{ paddingLeft: 16 }}>
                        {/* Skill Row */}
                        <div style={{ padding: '6px 18px 6px 0', borderBottom: '1px solid #0e1320', fontSize: 10, color: '#2a3548', textTransform: 'uppercase', letterSpacing: 1 }}>
                          {skill}
                        </div>

                        {skillTeams.map(team => (
                          <div key={team.id}
                            style={{ display: 'flex', alignItems: 'center', padding: '12px 18px 12px 0', borderBottom: '1px solid #0e1320', gap: 12 }}
                            onMouseEnter={e => e.currentTarget.style.background = '#0a0f1a'}
                            onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                          >
                            <div style={{ flex: 1, paddingLeft: 16 }}>
                              <div style={{ fontSize: 13, fontWeight: 600, color: '#d8e0f0' }}>{team.name}</div>
                              {team.coach_name && <div style={{ fontSize: 11, color: '#4a5568', marginTop: 2 }}>👤 {team.coach_name}{team.coach_phone ? ` · ${team.coach_phone}` : ''}</div>}
                              {team.location && <div style={{ fontSize: 11, color: '#4a5568' }}>📍 {team.location}</div>}
                            </div>
                            {team.jersey_colors && (
                              <div style={{ fontSize: 11, color: '#4a5568', background: '#0e1320', padding: '3px 8px', borderRadius: 4 }}>{team.jersey_colors}</div>
                            )}
                            {team.payment_method && (
                              <div style={{ fontSize: 11, color: '#4a5568', background: '#0e1320', padding: '3px 8px', borderRadius: 4 }}>{team.payment_method}</div>
                            )}
                            <button onClick={() => setEditTeam(team)}
                              style={{ background: 'transparent', border: '1px solid #1a2030', color: '#6b7a99', padding: '5px 10px', borderRadius: 6, fontSize: 11 }}>
                              Edit
                            </button>
                          </div>
                        ))}
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            ))}
          </div>
        ))}
      </div>

      {showAdd && (
        <TeamModal
          onClose={() => setShowAdd(false)}
          onSave={createTeam}
          searchOrgs={searchOrgs}
        />
      )}

      {editTeam && (
        <TeamModal
          initial={editTeam}
          onClose={() => setEditTeam(null)}
          onSave={data => updateTeam(editTeam.id, data)}
          searchOrgs={searchOrgs}
        />
      )}

      {showCSV && (
        <CSVModal
          onClose={() => setShowCSV(false)}
          onImport={bulkCreateTeams}
        />
      )}
    </div>
  )
}
